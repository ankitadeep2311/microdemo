package com.example.orders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrdersServiceApp {
  public static void main(String[] args) {
    SpringApplication.run(OrdersServiceApp.class, args);
  }
}
